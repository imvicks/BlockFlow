
# Steps to run project

### Terminal 1

```bash
python manage.py runserver
```

### Terminal 2

```bash
cd frontend
npm start
```
